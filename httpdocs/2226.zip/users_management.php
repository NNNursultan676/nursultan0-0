
<?php
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$success = '';
$error = '';
$isAdmin = ($_SESSION['role'] === 'admin');

// Обработка загрузки аватара
if (isset($_POST['upload_avatar'])) {
    check_csrf();
    
    $user_id = $isAdmin && isset($_POST['target_user_id']) ? intval($_POST['target_user_id']) : $_SESSION['user_id'];
    
    if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['avatar']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $max_size = 2 * 1024 * 1024; // 2MB
            if ($_FILES['avatar']['size'] <= $max_size) {
                $upload_dir = __DIR__ . '/uploads/avatars/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $new_filename = 'avatar_' . $user_id . '_' . time() . '.' . $ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['avatar']['tmp_name'], $upload_path)) {
                    // Удаляем старый аватар
                    $stmt = $pdo->prepare("SELECT avatar FROM users WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $old_avatar = $stmt->fetchColumn();
                    if ($old_avatar && file_exists(__DIR__ . '/' . $old_avatar)) {
                        unlink(__DIR__ . '/' . $old_avatar);
                    }
                    
                    $avatar_path = 'uploads/avatars/' . $new_filename;
                    $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    $stmt->execute([$avatar_path, $user_id]);
                    
                    regenerate_csrf_token();
                    $success = 'Аватар успешно обновлен!';
                } else {
                    $error = 'Ошибка при загрузке файла';
                }
            } else {
                $error = 'Файл слишком большой (максимум 2MB)';
            }
        } else {
            $error = 'Недопустимый формат файла (разрешены: jpg, jpeg, png, gif)';
        }
    }
}

// Обновление профиля
if (isset($_POST['update_profile'])) {
    check_csrf();
    
    $user_id = $isAdmin && isset($_POST['target_user_id']) ? intval($_POST['target_user_id']) : $_SESSION['user_id'];
    $username = trim($_POST['username'] ?? '');
    $full_name = trim($_POST['full_name'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    
    if (empty($username)) {
        $error = 'Логин не может быть пустым';
    } else {
        // Проверяем уникальность логина
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $stmt->execute([$username, $user_id]);
        if ($stmt->fetch()) {
            $error = 'Пользователь с таким логином уже существует';
        } else {
            $update_parts = ["username = ?", "full_name = ?"];
            $params = [$username, $full_name];
            
            // Если указан новый пароль
            if (!empty($new_password)) {
                if (strlen($new_password) < 4) {
                    $error = 'Пароль должен быть не менее 4 символов';
                } else {
                    $update_parts[] = "password = ?";
                    $params[] = password_hash($new_password, PASSWORD_DEFAULT);
                }
            }
            
            if (empty($error)) {
                $params[] = $user_id;
                $sql = "UPDATE users SET " . implode(", ", $update_parts) . " WHERE id = ?";
                $stmt = $pdo->prepare($sql);
                
                if ($stmt->execute($params)) {
                    regenerate_csrf_token();
                    $success = 'Профиль успешно обновлен!';
                    
                    // Обновляем сессию если пользователь изменил свой логин
                    if ($user_id === $_SESSION['user_id']) {
                        $_SESSION['username'] = $username;
                    }
                } else {
                    $error = 'Ошибка при обновлении профиля';
                }
            }
        }
    }
}

// Получаем данные пользователя для редактирования
$target_user_id = $isAdmin && isset($_GET['user_id']) ? intval($_GET['user_id']) : $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$target_user_id]);
$user_data = $stmt->fetch();

if (!$user_data) {
    header('Location: index.php');
    exit;
}

// Получаем список всех пользователей для админа
$all_users = [];
if ($isAdmin) {
    $all_users = $pdo->query("SELECT id, username, full_name, role, avatar, created_at FROM users ORDER BY username")->fetchAll();
}

$pageTitle = 'Управление профилями - Student Dark Notebook';
include 'includes/header.php';
?>

<div class="page-content">
    <h2 class="page-title">👤 Управление профилями</h2>
    
    <?php if ($success): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <?php if ($isAdmin): ?>
        <!-- Список всех пользователей для админа -->
        <div class="admin-section" style="margin-bottom: 30px;">
            <h3>👥 Все пользователи</h3>
            <div class="users-grid">
                <?php foreach ($all_users as $user): ?>
                    <div class="user-card <?php echo $user['id'] == $target_user_id ? 'active' : ''; ?>">
                        <a href="?user_id=<?php echo $user['id']; ?>" style="text-decoration: none; color: inherit;">
                            <div class="user-card-avatar">
                                <?php if ($user['avatar']): ?>
                                    <img src="<?php echo htmlspecialchars($user['avatar']); ?>" alt="Avatar">
                                <?php else: ?>
                                    <div class="avatar-placeholder">
                                        <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="user-card-info">
                                <strong><?php echo htmlspecialchars($user['username']); ?></strong>
                                <?php if ($user['full_name']): ?>
                                    <div class="text-secondary"><?php echo htmlspecialchars($user['full_name']); ?></div>
                                <?php endif; ?>
                                <div class="user-role">
                                    <?php echo $user['role'] === 'admin' ? '👑 Администратор' : '📚 Студент'; ?>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Форма редактирования профиля -->
    <div class="profile-container">
        <div class="profile-section">
            <h3>
                <?php if ($isAdmin && $target_user_id != $_SESSION['user_id']): ?>
                    Редактирование профиля: <?php echo htmlspecialchars($user_data['username']); ?>
                <?php else: ?>
                    Мой профиль
                <?php endif; ?>
            </h3>
            
            <!-- Аватар -->
            <div class="avatar-section">
                <div class="current-avatar">
                    <?php if ($user_data['avatar']): ?>
                        <img src="<?php echo htmlspecialchars($user_data['avatar']); ?>" alt="Avatar">
                    <?php else: ?>
                        <div class="avatar-placeholder-large">
                            <?php echo strtoupper(substr($user_data['username'], 0, 2)); ?>
                        </div>
                    <?php endif; ?>
                </div>
                
                <form method="POST" enctype="multipart/form-data" class="avatar-upload-form">
                    <?php echo csrf_field(); ?>
                    <?php if ($isAdmin && $target_user_id != $_SESSION['user_id']): ?>
                        <input type="hidden" name="target_user_id" value="<?php echo $target_user_id; ?>">
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="avatar">Загрузить новый аватар (jpg, png, gif, максимум 2MB)</label>
                        <input type="file" name="avatar" id="avatar" accept="image/*" required>
                    </div>
                    <input type="hidden" name="upload_avatar" value="1">
                    <button type="submit" class="btn-primary">📷 Обновить аватар</button>
                </form>
            </div>
            
            <!-- Основная информация -->
            <form method="POST" class="profile-form">
                <?php echo csrf_field(); ?>
                <?php if ($isAdmin && $target_user_id != $_SESSION['user_id']): ?>
                    <input type="hidden" name="target_user_id" value="<?php echo $target_user_id; ?>">
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="username">Логин *</label>
                    <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($user_data['username']); ?>" required minlength="3" maxlength="50">
                </div>
                
                <div class="form-group">
                    <label for="full_name">Полное имя</label>
                    <input type="text" name="full_name" id="full_name" value="<?php echo htmlspecialchars($user_data['full_name'] ?? ''); ?>" maxlength="100">
                </div>
                
                <div class="form-group">
                    <label for="new_password">Новый пароль (оставьте пустым, чтобы не менять)</label>
                    <input type="password" name="new_password" id="new_password" minlength="4">
                </div>
                
                <?php if ($isAdmin): ?>
                    <div class="info-box">
                        <strong>Дополнительная информация:</strong><br>
                        Роль: <?php echo $user_data['role'] === 'admin' ? 'Администратор' : 'Студент'; ?><br>
                        Зарегистрирован: <?php echo date('d.m.Y H:i', strtotime($user_data['created_at'])); ?><br>
                        <?php if ($isAdmin): ?>
                            Хеш пароля: <code style="font-size: 11px; word-break: break-all;"><?php echo htmlspecialchars($user_data['password']); ?></code>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <input type="hidden" name="update_profile" value="1">
                <button type="submit" class="btn-primary">💾 Сохранить изменения</button>
                
                <?php if ($isAdmin && count($all_users) > 1): ?>
                    <a href="?" class="btn-secondary" style="margin-left: 10px;">◀ Вернуться к моему профилю</a>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<style>
.users-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 15px;
    margin-top: 20px;
}

.user-card {
    background: var(--bg-dark);
    border: 2px solid var(--border-sketch);
    border-radius: 8px;
    padding: 15px;
    transition: all 0.3s ease;
    cursor: pointer;
}

.user-card:hover {
    border-color: var(--accent-primary);
    transform: translateY(-2px);
}

.user-card.active {
    border-color: var(--accent-primary);
    background: rgba(124, 179, 66, 0.1);
}

.user-card-avatar {
    text-align: center;
    margin-bottom: 10px;
}

.user-card-avatar img {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    object-fit: cover;
    border: 2px solid var(--accent-primary);
}

.avatar-placeholder {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background: var(--accent-primary);
    color: white;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
    font-weight: bold;
}

.user-card-info {
    text-align: center;
}

.user-role {
    margin-top: 5px;
    font-size: 12px;
    color: var(--text-secondary);
}

.profile-container {
    max-width: 800px;
    margin: 0 auto;
}

.profile-section {
    background: var(--bg-card);
    border: 2px solid var(--border-sketch);
    border-radius: 8px;
    padding: 30px;
}

.profile-section h3 {
    margin-bottom: 25px;
    color: var(--accent-primary);
}

.avatar-section {
    display: flex;
    gap: 30px;
    align-items: flex-start;
    margin-bottom: 30px;
    padding-bottom: 30px;
    border-bottom: 1px solid var(--border-sketch);
}

.current-avatar {
    flex-shrink: 0;
}

.current-avatar img {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid var(--accent-primary);
}

.avatar-placeholder-large {
    width: 150px;
    height: 150px;
    border-radius: 50%;
    background: var(--accent-primary);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 60px;
    font-weight: bold;
    border: 3px solid var(--accent-primary);
}

.avatar-upload-form {
    flex: 1;
}

.profile-form .form-group {
    margin-bottom: 20px;
}

.info-box {
    background: var(--bg-dark);
    border: 1px solid var(--border-sketch);
    border-radius: 6px;
    padding: 15px;
    margin: 20px 0;
    font-size: 14px;
    line-height: 1.8;
}

.text-secondary {
    color: var(--text-secondary);
    font-size: 14px;
}

.btn-secondary {
    display: inline-block;
    background: var(--bg-dark);
    color: var(--text-primary);
    padding: 10px 20px;
    border: 2px solid var(--border-sketch);
    border-radius: 6px;
    text-decoration: none;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-secondary:hover {
    border-color: var(--accent-primary);
    background: var(--bg-card);
}
</style>

<?php include 'includes/footer.php'; ?>
